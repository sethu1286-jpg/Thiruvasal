# 🔧 Fix Vercel Deployment — Step by Step

## ❌ What Went Wrong
Vercel couldn't find `public/index.html` because:
1. Your GitHub folder was named `Public` (capital P) — Linux is case-sensitive
2. The old `vercel.json` had a wrong build config

## ✅ What's Fixed in This ZIP
- `vercel.json` → simplified to just rewrites (correct for React CRA)
- `package.json` → cleaned up scripts
- `public/index.html` → correct lowercase folder name
- `public/favicon.ico` → added (was missing)
- `src/services/firebase.js` → pre-filled with your project values

---

## 📋 GitHub: Exact Folder Structure Required

Your repo root must look EXACTLY like this (case-sensitive!):

```
Thiruvasal/                     ← your repo root
├── public/                     ← MUST be lowercase "public"
│   ├── index.html              ← MUST exist here
│   ├── manifest.json
│   └── favicon.ico             ← NEW - add this
├── src/
│   ├── index.js
│   ├── App.jsx
│   ├── context/
│   │   └── AuthContext.js
│   ├── services/
│   │   └── firebase.js
│   ├── hooks/
│   │   ├── useDonors.js
│   │   └── useBusinesses.js
│   ├── components/
│   │   └── UI.jsx
│   ├── screens/
│   │   ├── LoginScreen.jsx
│   │   ├── HomeScreen.jsx
│   │   ├── CharityScreen.jsx
│   │   ├── BusinessScreen.jsx
│   │   ├── ProfileScreen.jsx
│   │   └── AdminScreen.jsx
│   └── styles/
│       ├── global.css
│       └── theme.js
├── .gitignore
├── firebase.json
├── firestore.rules
├── firestore.indexes.json
├── package.json
├── vercel.json
└── README.md
```

---

## 🚀 Upload Steps on GitHub Mobile

### Option A — Delete old Public folder, upload new
1. Open your GitHub repo on mobile browser
2. Go into the `Public` folder (capital P)
3. Tap `index.html` → tap pencil (edit) → tap `...` → **Delete file**
4. Repeat for `manifest.json`  
5. Now the old `Public` folder is gone
6. Go to repo root → tap `Add file` → `Upload files`
7. Upload the new `public/` folder contents from this ZIP

### Option B — Rename via GitHub web (easier)
1. Open `Public/index.html` in GitHub
2. Tap edit (pencil icon)
3. In the filename box at top, change `Public/index.html` to `public/index.html`
4. Scroll down → Commit changes
5. Repeat for `manifest.json`
6. Upload `favicon.ico` to the `public/` folder

---

## ⚙️ Vercel Environment Variables (CRITICAL)

In Vercel Dashboard → Your Project → Settings → Environment Variables
Add these 6 variables (get your apiKey from Firebase Console):

| Name | Value |
|------|-------|
| REACT_APP_FIREBASE_API_KEY | (get from Firebase Console → Project Settings → SDK) |
| REACT_APP_FIREBASE_AUTH_DOMAIN | thiruvasal.firebaseapp.com |
| REACT_APP_FIREBASE_PROJECT_ID | thiruvasal |
| REACT_APP_FIREBASE_STORAGE_BUCKET | thiruvasal.firebasestorage.app |
| REACT_APP_FIREBASE_MESSAGING_SENDER_ID | 1013411348504 |
| REACT_APP_FIREBASE_APP_ID | 1:1013411348504:web:a34bea6fc6b |

After adding → click **Redeploy**

---

## 🔑 Get Your API Key

1. Go to console.firebase.google.com
2. Select project `thiruvasal`
3. Click gear icon → **Project Settings**
4. Scroll to **Your apps** → `thiruvasal-web`
5. Click **SDK setup and configuration**
6. Copy the `apiKey` value (starts with `AIzaSy...`)

---

## ✅ Firestore Rules — Set to Test Mode

In Firebase Console → Firestore → Rules tab, paste this temporarily:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Click **Publish** → this allows all logged-in users to read/write.

